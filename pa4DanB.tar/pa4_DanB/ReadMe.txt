Program works under this condition:
1) You must create a variable ( e.g.a= 1 ) before using the ? for the inventory.
2) Entering PI or PHI will also allow the program to invoke ? for the inventory.

If the above instructions are adhered to, the program will run until a syntax error
is entered or the escape sequence is entered.

Any other input will result in a segmentation fault I am trying to hunt down and fix.